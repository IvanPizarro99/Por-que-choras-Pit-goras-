from scripts.startgame import StartGame

if __name__ == "__main__":
    game = StartGame()
    game.run()

# ARQUIVO PRINCIPAL DE EXECUÇÃO DO GAME
